#!/bin/sh

#

sed 's/	/ \& /g' ../temp/multi_de_en_hu_arab_dari_bos_cro_ser.h.r > ../temp/multi_de_en_hu_arab_dari_bos_cro_ser.h.amp
sed 's/	/ \& /g' ../temp/multi_de_en_hu_arab_dari_bos_cro_ser.d.r > ../temp/multi_de_en_hu_arab_dari_bos_cro_ser.d.amp
